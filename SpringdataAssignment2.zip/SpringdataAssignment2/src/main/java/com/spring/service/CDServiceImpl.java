package com.spring.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.spring.Dao.CDRepository;
import com.spring.entity.CD;

@Service
public class CDServiceImpl implements CDService {
	
	@Autowired
	private CDRepository cdRepository;

	
	public Iterable<CD> findAll() {
		
		return cdRepository.findAll();
	}

	
	public CD findByTitle(String Title) {
		return cdRepository.findBycdtitle(Title);
	}
	
	public CD AddCD(CD cd) {
		
		return cdRepository.save(cd);
	}
	
	public void DeleteCD(Long id) {
		cdRepository.deleteById(id);
	}
	
	public CD updateCD(Long id, CD cd) {
		
		CD c=cdRepository.findByCDId(id).get();
		
		c.setCdprice(cd.getCdprice());
		c.setCdtitle(cd.getCdtitle());
		c.setCdpublisher(cd.getCdpublisher());
		
		CD Cd= cdRepository.save(c);
		return Cd;
	}
	

}

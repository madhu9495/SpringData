package com.spring.service;



import com.spring.entity.CD;

public interface CDService {
	
	public Iterable<CD> findAll();
	
	public CD findByTitle(String Title);
	
	public CD AddCD(CD cd);
	
	public void DeleteCD(Long id);
	
	public CD updateCD(Long id, CD cd);

}

package com.spring.Controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.entity.CD;
import com.spring.service.CDServiceImpl;

@RestController
@RequestMapping(value="/CD")
public class CDController {
	
	@Autowired
	private CDServiceImpl cdServiceImpl;
	
	@GetMapping(value="/AllCDs")
    public ResponseEntity<Iterable<CD>> findAllCDs(){
		
		Iterable<CD> AllCDs= cdServiceImpl.findAll();
		
		return new ResponseEntity<Iterable<CD>>(AllCDs, HttpStatus.OK);
	}
	
	@GetMapping(value="/CDByTilte/{title}")
	public ResponseEntity<CD> getCDByTilte(@PathVariable(value ="title") String title) {
		
		 CD cd=cdServiceImpl.findByTitle(title);
		
		return new ResponseEntity<CD>(cd, HttpStatus.ACCEPTED);
	}
	
	@PostMapping(value="/AddCD")
	public ResponseEntity<CD> addCD(@Valid @RequestBody CD cd){
		
		CD Cd= cdServiceImpl.AddCD(cd);
		
		return new ResponseEntity<CD>(Cd, HttpStatus.CREATED);
	}
	
	@PutMapping(value="/getCD/{id}")
	public ResponseEntity<CD> getCd(@PathVariable(value="id") Long id, @Valid @RequestBody CD cd){
		CD c=cdServiceImpl.updateCD(id, cd);
		
		return new ResponseEntity<CD>(c, HttpStatus.ACCEPTED);
	}
	
	@DeleteMapping(value="/DeleteCD/{id}")
	public ResponseEntity<String> DeleteCD(@PathVariable(value="id") Long id) {
		 
		cdServiceImpl.DeleteCD(id);
		
		return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
	}
	

}

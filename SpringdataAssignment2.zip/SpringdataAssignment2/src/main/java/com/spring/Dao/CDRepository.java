package com.spring.Dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.spring.entity.CD;

@Repository
public interface CDRepository extends CrudRepository<CD, Long> {
	
	public CD findBycdtitle(String cdtitle);
	
	@Query("SELECT c FROM CD c WHERE c.cdid= :id")
	public Optional<CD> findByCDId(@Param("id") Long id);
	

}

INSERT INTO CD (cdprice,cdpublisher,cdtitle) VALUES (101.40,'RaviVarma','TheEnd');
INSERT INTO CD (cdprice,cdpublisher,cdtitle) VALUES (215,'Raghuvir','FlyHigh');
INSERT INTO CD (cdprice,cdpublisher,cdtitle) VALUES (208.60,'Arya','Wonder');
commit;
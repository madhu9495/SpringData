package com.spring.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.Dao.CDRepository;
import com.spring.entity.CD;

@Service
public class CDServiceImpl implements CDService {
	
	@Autowired
	private CDRepository cdRepository;

	@Override
	public Iterable<CD> findAll() {
		
		return cdRepository.findAll();
	}

	@Override
	public CD findByTitle(String Title) {
		return cdRepository.findBycdtitle(Title);
	}

}

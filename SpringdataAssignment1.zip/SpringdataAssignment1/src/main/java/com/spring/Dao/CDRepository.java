package com.spring.Dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.spring.entity.CD;

@Repository
public interface CDRepository extends CrudRepository<CD, Long> {
	
	public CD findBycdtitle(String cdtitle);

}

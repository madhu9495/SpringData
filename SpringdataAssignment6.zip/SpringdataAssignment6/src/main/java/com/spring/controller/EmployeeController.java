package com.spring.controller;

import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.spring.entities.Employee;
import com.spring.service.EmployeeServiceImpl;

@RestController
@RequestMapping(value = "/Employee")
public class EmployeeController {

	@Autowired
	EmployeeServiceImpl employeeServiceImpl;

	@PostMapping(value = "/AddEmployee")
	public ResponseEntity<Employee> addEmployee(@Valid @RequestBody Employee emp) {

		Employee Emp = employeeServiceImpl.AddEmployee(emp);

		return new ResponseEntity<Employee>(Emp, HttpStatus.CREATED);

	}

	@GetMapping(value = "/AllEmployees")
	public ResponseEntity<Iterable<Employee>> allEmployees() {

		Iterable<Employee> allEmps = employeeServiceImpl.findAll();

		return new ResponseEntity<Iterable<Employee>>(allEmps, HttpStatus.ACCEPTED);
	}
	
	@DeleteMapping(value="/DeleteEmployee/{id}")
	public ResponseEntity<String> deleteEmployee(@PathVariable(value="id") Long id){
		
		employeeServiceImpl.DeleteEmployee(id);
		
		return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
		
	}
	
	@PutMapping(value="/UpdateEmployee/{id}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable(value="id") Long id, @Valid @RequestBody Employee emp){
		
		Employee Emp= employeeServiceImpl.UpdateEmployee(id, emp);
		
		return new ResponseEntity<Employee>(Emp,HttpStatus.ACCEPTED);
	}
	
	@GetMapping(value="/getEmployee/{id}")
	public ResponseEntity<Employee> getEmployee(@PathVariable(value="id") Long id){
		
		Employee emp = employeeServiceImpl.findByEmpId(id);
		
		return new ResponseEntity<Employee>(emp,HttpStatus.ACCEPTED);
		
	}
	
	@GetMapping(value="/getEmployee")
	public ResponseEntity<Employee> getEmployeeByName(@RequestParam("EmpName") String name){
		
		Employee emp=employeeServiceImpl.findByEmpName(name);
		
		return new ResponseEntity<Employee>(emp,HttpStatus.ACCEPTED);
	}
	
	@GetMapping(value="getEmployeeByDoJ")//Date must be in yyyy-mm-dd
public ResponseEntity<Iterable<Employee>> getEmployeeByDoJ(@RequestParam("EmpDateOfJoin") @DateTimeFormat(pattern="yyyy-mm-dd") Date doj){
		
		Iterable<Employee> emp=employeeServiceImpl.findByEmpDoj(doj);
		
		return new ResponseEntity<Iterable<Employee>>(emp,HttpStatus.ACCEPTED);
	}

}

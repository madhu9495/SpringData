package com.spring.repository;


import java.util.Date;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.spring.entities.Employee;



@Repository
public interface EmployeeRepository extends CrudRepository<Employee, Long>{
	
	@Query("SELECT e FROM Employee e WHERE e.empid= :empid")
	public Optional<Employee> findByEmpId(@Param("empid") Long id);
	
	@Query("SELECT e FROM Employee e")
	public Iterable<Employee> findAll();
	
	@Query("SELECT e FROM Employee e WHERE LOWER(e.empname)= LOWER(:empname)")
	public Optional<Employee> findByEmpName(@Param("empname") String name);
	
	@Query("SELECT e FROM Employee e WHERE e.empdoj >= :empdoj")
	public Iterable<Employee> findByEmpDoj(@Param("empdoj") Date empdoj);
	

}

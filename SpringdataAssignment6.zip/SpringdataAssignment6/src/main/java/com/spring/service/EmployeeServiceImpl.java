package com.spring.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.entities.Employee;
import com.spring.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepository employeeRepository;

	public Employee AddEmployee(Employee emp) {

		return employeeRepository.save(emp);
	}

	public Employee UpdateEmployee(Long id, Employee emp) {

		Employee Emp = employeeRepository.findById(id).get();

		Emp.setEmpdoj(emp.getEmpdoj());
		Emp.setEmpname(emp.getEmpname());
		Emp.setEmptotalsalary(emp.getEmptotalsalary());
		Emp.setEmployeetype(emp.getEmployeetype());;

		Employee employee = employeeRepository.save(Emp);

		return employee;
	}

	public void DeleteEmployee(Long id) {

		employeeRepository.deleteById(id);

	}

	public Iterable<Employee> findAll() {

		return employeeRepository.findAll();
	}

	public Employee findByEmpId(Long id) {

		return employeeRepository.findByEmpId(id).get();
	}

	public Employee findByEmpName(String name) {

		return employeeRepository.findByEmpName(name).get();
	}

	public Iterable<Employee> findByEmpDoj(Date empdoj) {

		return employeeRepository.findByEmpDoj(empdoj);
	}

}

package com.spring.service;

import java.util.Date;

import com.spring.entities.Employee;

public interface EmployeeService {
	
	public Employee AddEmployee(Employee emp);
	
	public Employee UpdateEmployee(Long id, Employee emp);
	
	public void DeleteEmployee(Long id);
	
	public Iterable<Employee> findAll();
	
	public Employee findByEmpId(Long id);
	
	public Employee findByEmpName(String name);
	
	public Iterable<Employee> findByEmpDoj(Date empdoj);

}

package com.spring.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="employee2")
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long empid;
	
	@Column
	@NotNull
	private String empname;
	
	@Column
	@NotNull
	private Date empdoj;
	
	@Column
	@NotNull
	private float emptotalsalary;
	
	@Column
	@NotNull
	private String employeetype;
	
	public Long getEmpid() {
		return empid;
	}

	public void setEmpid(Long empid) {
		this.empid = empid;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public Date getEmpdoj() {
		return empdoj;
	}

	public void setEmpdoj(Date empdoj) {
		this.empdoj = empdoj;
	}

	public float getEmptotalsalary() {
		return emptotalsalary;
	}

	public void setEmptotalsalary(float emptotalsalary) {
		this.emptotalsalary = emptotalsalary;
	}

	public String getEmployeetype() {
		return employeetype;
	}

	public void setEmployeetype(String employeetype) {
		this.employeetype = employeetype;
	}

	

	


}

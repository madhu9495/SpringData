package com.spring.Dao;

import java.util.Optional;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.spring.entity.CD;

@Repository
public interface CDRepository extends CrudRepository<CD, Long> {
	
	public CD findBycdtitle(String cdtitle);
	
	@Query("SELECT c FROM CD c WHERE c.cdid= :id")
	public Optional<CD> findByCDId(@Param("id") Long id);
	
	@Query("SELECT c FROM CD c WHERE c.cdprice between ?1 and ?2")
	public Iterable<CD> findByPriceRange(float lowerprice, float upperprice);
	
	@Query("SELECT c FROM CD c WHERE c.cdprice between :lowerprice and :upperprice")
	public Iterable<CD> findByPriceRangeNamedParams(@Param("lowerprice") float lowerprice, @Param("upperprice") float upperprice);
	
	@Query("SELECT c FROM CD c WHERE c.cdtitle LIKE CONCAT('%',:title,'%')")
	public Iterable<CD> findByTitleMatch(@Param("title") String title);
	
	@Query(value="SELECT * FROM CD c WHERE c.cdtitle LIKE CONCAT('%',:title,'%')",
			nativeQuery= true)
	public Iterable<CD> findByTitleNative(@Param("title") String title);
	
	public Iterable<CD> findAll(Sort sort);
	
	
	public Iterable<CD> findbyCdPrice(@Param("cdprice") float cdprice);

}

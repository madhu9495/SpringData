package com.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import com.spring.Dao.CDRepository;
import com.spring.entity.CD;

@Service
public class CDServiceImpl implements CDService {

	@Autowired
	private CDRepository cdRepository;

	public Iterable<CD> findAll() {

		return cdRepository.findAll();
	}

	public CD findByTitle(String Title) {
		return cdRepository.findBycdtitle(Title);
	}

	public CD AddCD(CD cd) {

		return cdRepository.save(cd);
	}

	public void DeleteCD(Long id) {
		cdRepository.deleteById(id);
	}

	public CD updateCD(Long id, CD cd) {

		CD c = cdRepository.findByCDId(id).get();

		c.setCdprice(cd.getCdprice());

		c.setCdtitle(cd.getCdtitle());
		c.setCdpublisher(cd.getCdpublisher());

		CD Cd = cdRepository.save(c);
		return Cd;
	}

	public Iterable<CD> findByPriceRange(float lowerprice, float upperprice) {

		return cdRepository.findByPriceRange(lowerprice, upperprice);
	}

	public Iterable<CD> findByPriceRangeNamedParams(float lowerprice, float upperprice) {

		return cdRepository.findByPriceRangeNamedParams(lowerprice, upperprice);
	}

	public Iterable<CD> findByTitleMatch(String title) {

		return cdRepository.findByTitleMatch(title);
	}

	public Iterable<CD> findAllSortByTitle() {

		Sort sort = new Sort(Sort.Direction.ASC, "cdtitle");

		return cdRepository.findAll(sort);
	}

	public Iterable<CD> findAllSortByPrice() {

		Sort sort = new Sort(Sort.Direction.DESC, "cdprice");

		return cdRepository.findAll(sort);
	}

	
	public Iterable<CD> findByCdPrice(float cdprice) {
		
		 return cdRepository.findbyCdPrice(cdprice);
	}
}

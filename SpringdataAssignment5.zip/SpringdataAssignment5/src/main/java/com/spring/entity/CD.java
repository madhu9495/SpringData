package com.spring.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="cd")
@NamedQuery(name="CD.findbyCdPrice",
      query="SELECT c FROM CD c WHERE c.cdprice > :cdprice")
public class CD {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long cdid;
	
	@Column
	@NotNull
	private String cdtitle;
	
	@Column
	@NotNull
	private float cdprice;
	
	@Column
	@NotNull
	private String cdpublisher;

	public Long getCdid() {
		return cdid;
	}

	public void setCdid(Long cdid) {
		this.cdid = cdid;
	}

	public String getCdtitle() {
		return cdtitle;
	}

	public void setCdtitle(String cdtitle) {
		this.cdtitle = cdtitle;
	}

	public float getCdprice() {
		return cdprice;
	}

	public void setCdprice(float cdprice) {
		this.cdprice = cdprice;
	}

	public String getCdpublisher() {
		return cdpublisher;
	}

	public void setCdpublisher(String cdpublisher) {
		this.cdpublisher = cdpublisher;
	}
	
	

}
